########
Contents
########

.. toctree::
   :maxdepth: 2

   usage
   api
   syntax
